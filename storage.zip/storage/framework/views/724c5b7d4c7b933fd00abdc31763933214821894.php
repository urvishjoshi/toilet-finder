<?php $__env->startSection('title','Sales'); ?>


<?php $__env->startSection('sale'); ?>
<section>
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md text-center">
					<h2>Your Sales</h2>
				</div><!-- /.col -->
			</div>
			<HR width=50%>
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->
	<div class="content-header mt-0 pt-0">
		<div class="container-fluid">
			<div class="container justify-content-center" id="requestTable">
				<div class="card">
					<div class="card-header border-0 p-0">
						<div class="container justify-content-center p-0" id="requestTable">
							<table class="table align-items-center table-hover table-flush text-center mb-0">
								<thead>
									<tr class="thead-light">
										<th scope="col">Transact Id</th>
										<th scope="col">Toilet name</th>
										<th scope="col">User id</th>
										<th scope="col">Paid</th>
										<th scope="col">Used on	</th>
									</tr>
								</thead>
								<tbody>
								<?php if( count($sales) <1 ): ?>
									<tr><td colspan="5"><center><h2>No sales yet</h2></center></td></tr>
								<?php else: ?>
								<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if( count($sale->usages) <1 ): ?>
										<tr><td colspan="5"><center><h2>No confirmed sales yet</h2></center></td></tr> <?php break; ?>
									<?php else: ?>
										<?php for($i=0;$i<count($sale->usages);$i++): ?>
												<tr>
													<td><?php echo e($sale->usages[$i]['transaction_id']); ?></td>
													<td><?php echo e($sale['toilet_name']); ?></td>
													<td>
														<?php echo e($sale->usages[$i]['id']); ?>

													</td>
													<td><b>$<?php echo e($sale['price']); ?></b></td>
													<td><?php echo e($sale->usages[$i]['created_at']->format('d/m/Y').' at '.$sale->usages[$i]['created_at']->format('g:i A')); ?></td>
												</tr>
										<?php endfor; ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/toiletowner/sale.blade.php ENDPATH**/ ?>