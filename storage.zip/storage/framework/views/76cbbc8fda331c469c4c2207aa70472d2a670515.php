<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('home'); ?>
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-9">
					<h1 class="m-0 text-dark">Dashboard</h1>
				</div><!-- /.col -->
				<div class="custom-control custom-switch ml-5">
					<input type="checkbox" class="custom-control-input" name="autoalloc" id="autoalloc" value="<?php echo e($autoalloc[0]['auto_allocate']==0 ? '0' : '1'); ?>" <?php echo e($autoalloc[0]['auto_allocate']==1 ? 'checked' : ''); ?>>
					<?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
          
					<label class="custom-control-label" style="font-size: 18px;" for="autoalloc">Auto allocate toilets</label>
				</div>
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<!-- Small boxes (Stat box) -->
			<div class="row">
				<div class=" col-lg-3 col-6">
					<!-- small box -->
					<div class="small-box bg-success border border-light" style="height: 150px;">

						<div class="inner pl-3">
							<h3><?php echo e($data['usages']); ?></h3>

							<h4 class="">Toilet usages</h4>
						</div>
						<div class="icon">
						   <i class="fas fa-users"></i>
						</div>
				</div>
				</div>
				<!-- ./col -->
				<div class="col-lg-3 col-6 ml-4">
					<!-- small box -->
					<div class="small-box bg-warning border border-light" style="height: 150px;">
						<div class="inner pl-3">
							<span style="font-size: 35px;"><b><?php echo e($data['active']); ?></b>/</span><?php echo e($data['toilets']); ?>

							<h4>Active Toilets</h4><!--Kishan changed User Registrations-->
						</div>
						<div class="icon">
                			<i class="material-icons" style="color:##006652;">flash_on</i>
						</div>
						
					</div>
				</div>
				<!-- ./col -->
			</div>
			<!-- /.row -->

			
          <!-- /.col -->
      	</div><!-- Row 2nd end -->

		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content -->
<script>

$(document).ready(function() {
    $('#autoalloc').change(function() {
        if($('#autoalloc').val()=='0')
        	$("#requestlink").hide();
        else
            $("#requestlink").show();
        $.ajax({
            url: '<?php echo e(route('dashboard.store')); ?>',
            data: {
                   'autoalloc': $('#autoalloc').val(),
                    '_token': $('input[name=_token]').val(),
                    '_method': $('input[name=_method]').val(),
                  },
            type: 'POST',
            dataType: 'json',
            success: function (response) {

                $('#autoalloc').attr('value', response.status);

            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/toiletowner/home.blade.php ENDPATH**/ ?>