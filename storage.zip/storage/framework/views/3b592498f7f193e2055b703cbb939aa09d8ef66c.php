<?php $__env->startSection('title','Toilet Locations'); ?>

<?php $__env->startSection('location'); ?>

<section>
	<div class="content pt-2">
		<div class="container">
			<div class="row">
				<div class="col-md text-center">
					<h2>Add Location</h2>
				</div><!-- /.col -->
			</div><!-- /.row -->
			<HR width=50%>
		</div><!-- /.container-fluid -->
    </div>

	<div class="content-header">
		<div class="container">
 			<?php echo method_field('GET'); ?> <?php echo csrf_field(); ?>
 			
			<form action="<?php echo e(route('a.locations.update','deletecity')); ?>" method="POST">
 				<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
				<h6 class="heading-small text-muted mb-2">Delete city</h6>
 				<div class="row">
					<div class="col-lg">
						<div class="form-group">
							<label for="countryId">Country</label>
							<select name="countryId" class="form-control" id="country">
		 						<option>select</option>
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 						</select>
						</div>
					</div>
					<div class="col-lg">
						<div class="form-group">
							<label for="state">State</label>
							<select name="stateId" class="form-control" id="state">
	 						 	<option value="">-select-</option>
							</select>
						</div>
					</div>
					<div class="col-lg">
						<div class="form-group">
							<label for="city">City</label>
							<select name="city" class="form-control" id="city" required>
								<option value="">-select-</option>
							</select>
						</div>
					</div>
					<div class="col-lg">
						<div class="form-group">
							<label for="addCountry"></label>
							<button type="submit" class="btn btn-danger d-flex align-items-end mt-2" id="delCityBtn" name="citydelete">
								Delete City
							</button>
						</div>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</section>



<script>
$(document).ready(function(){

	$('#delCountryDiv').hide();
	$('#delStateDiv').hide();
	$('#delCityDiv').hide();

	$('#delCountryBtn').click(function(event) {
		$('#delCountryDiv').show();
		$('#delStateDiv').hide();
		$('#delCityDiv').hide();
	});
	$('#delStateBtn').click(function(event) {
		$('#delStateDiv').show();
		$('#delCountryDiv').hide();
		$('#delCityDiv').hide();
	});
	$('#delCityBtn').click(function(event) {
		$('#delCityDiv').show();
		$('#delCountryDiv').hide();
		$('#delStateDiv').hide();
	});


	$("#country").on('change',function(){
		$.ajax({
			method:"POST",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
               'country_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': $('input[name=_method]').val(),
            },
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#state").html('<option>-No state found-</option>');
				else
					$("#state").html(data);
			}
		});
	});

	$("#state").on('change',function(){
		$.ajax({
			method:"POST",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
               'state_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': $('input[name=_method]').val(),
            },
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#city").html('<option value="">-No city found-</option>');
				else
					$("#city").html(data);
			}
		});
	});
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/locations/city.blade.php ENDPATH**/ ?>