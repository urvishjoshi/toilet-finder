<?php $__env->startSection('title','Reports'); ?>

<?php $__env->startSection('report'); ?>
<section>
	<div class="container pt-3">
		<div class="container col-auto pb-0">
			<div class="row pb-0">
				<div class="col-md pb-0 text-center">
					<h2 class=" mb-0">Toilet Reports</h2>
				</div>
			</div>
			<HR width=40%>
		</div>
	</div>
	<div class="content-header mt-0 pt-1">
		<div class="container-fluid">
			<div>
				<form action="<?php echo e(route('a.reports.show',1)); ?>" method="post" id="form" class="row justify-content-center">
				<?php echo method_field('GET'); ?> <?php echo csrf_field(); ?>
				<div class="col-md-auto">
					<select class="custom-select" id="selectRange" name="selectRange">
						<option disabled="">Select range</option>
						<option value="7">7 days</option>
						<option value="31">30 days</option>
						<option value="6">6 months</option>
						<option value="12">1 year</option>
						<option value="1">All</option>
					</select>
				</div>
				<div class="col-md-auto">
					<button class="btn btn-primary" value="getReport" name="getReport" type="submit">Get Reports</button>
				</div>
				</form>
			</div>
			<div class="container-fluid justify-content-center mt-3" id="tableContainer">
			</div>
		</div>
	</div>
</section>
<script>
$(document).ready(function(){
	$("#form").on('submit',function(){
		event.preventDefault();
		$.ajax({
			method:"POST",
			url:"<?php echo e(route('a.reports.show',1)); ?>",
			data: {
               'selectRange': $('#selectRange :selected').val(),
                '_token': $('input[name=_token]').val(),
                '_method': $('input[name=_method]').val(),
            },
			dataType:'html',
			success:function(data){
				$("#tableContainer").html(data);
			}
		});
	});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/report/index.blade.php ENDPATH**/ ?>