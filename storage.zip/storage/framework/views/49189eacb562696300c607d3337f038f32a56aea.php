<?php $__env->startSection('title','Edit Toilet'); ?>

<?php $key=\App\Model\Admin::first('mapkey'); ?>

<?php $__env->startSection('toilet.show'); ?>
	<section class="content">
		<div class="container pt-3">
				<div class="container col-md-auto">
				<div class="row">
					<div class="col-md-1">
						<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
					</div>
					<div class="col-md text-center mr-4">
						<h2>Edit toilet<b></b></h2>
						<hr width=25%>
					</div>
				</div>
    		</div><!-- /.container-fluid -->
    	</div>
		    <form action="<?php echo e(route('a.toilets.update', $toilet[0]->id)); ?>" method="post">
		    	<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
		    	<div class="modal-body row bg-white">
				<div class="col-6">
					<h6 class="heading-small text-muted mb-2">Toilet information</h6>
					<div class="lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toiletname">Toilet name</label>
									<input type="text" id="toiletname" name="toiletname" class="form-control" placeholder="Toilet name" value="<?php echo e($toilet[0]->toilet_name); ?>">
									<?php if ($errors->has('toiletname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('toiletname'); ?>
									    <span class="text-danger font-14" role="alert">
									        <strong><?php echo e($message); ?></strong>
									    </span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toiletstatus">Toilet status</label>
									<select class="custom-select" id="toiletstatus" name="toiletstatus">
										<option disabled>Status</option>
										<option value="1" class="text-success" <?php echo e($toilet[0]->status==1 ? 'selected' : ''); ?>>Active</option>
										<option value="0" class="text-danger" <?php echo e($toilet[0]->status==0 ? 'selected' : ''); ?>>Not active</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="lg-4">
						<div class="row">
							<div class="form-group col-md-2 px-1">
								<label class="form-control-label" for="toiletprice">Price in <b>KD</b></label>
								<input id="toiletprice" name="toiletprice" class="form-control px-1" placeholder="KD" value="<?php echo e($toilet[0]->price); ?>" type="number" min="0" step="0.001" required>
								<?php if ($errors->has('toiletprice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('toiletprice'); ?>
								    <span class="text-danger font-14" role="alert">
								        <strong><?php echo e($message); ?></strong>
								    </span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="form-control-label" for="toilettype">Toilet type</label>
									<select class="custom-select" id="toilettype" name="toilettype">
										<option disabled>toilet for</option>
										<option value="2" <?php echo e($toilet[0]->type==2 ? 'selected' : ''); ?>>Male & Female</option>
										<option value="1" <?php echo e($toilet[0]->type==1 ? 'selected' : ''); ?>>Male only</option>
										<option value="0" <?php echo e($toilet[0]->type==0 ? 'selected' : ''); ?>>Female only</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="complexname">Complex name</label>
									<input id="complexname" name="complexname" class="form-control" placeholder="Toilet Address" value="<?php echo e($toilet[0]->complex_name); ?>" type="text">
									<?php if ($errors->has('complexname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('complexname'); ?>
									    <span class="text-danger font-14" role="alert">
									        <strong><?php echo e($message); ?></strong>
									    </span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-lg-12">
								<label class="form-control-label" for="address">Street Address</label>
								<input type="text" id="address" name="address" class="form-control" placeholder="Street address of your toilet" value="<?php echo e($toilet[0]->address); ?>">
								<?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
								    <span class="text-danger font-14" role="alert">
								        <strong><?php echo e($message); ?></strong>
								    </span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="country">Country</label>
									<select name="country" class="form-control" id="country" required>
				 						
										<?php $__currentLoopData = $datas->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <option value="<?php echo e($country['id']); ?>"
										    <?php if($country['id'] == $toilet[0]->country_id): ?>
										        selected="selected"
										    <?php endif; ?>
										    ><?php echo e($country['country']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 						</select>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="form-group">
									<label for="state">Governance</label>
 									<select name="state" class="form-control" id="state" required>
 										<?php $__currentLoopData = $datas->states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <option value="<?php echo e($state['id']); ?>"
										    <?php if($state['id'] == $toilet[0]->state_id): ?>
										        selected="selected"
										    <?php endif; ?>
										    ><?php echo e($state['state']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 									</select>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="form-group">
									<label for="city">City</label>
									<select name="city" class="form-control" id="city" required>
										<?php $__currentLoopData = $datas->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <option value="<?php echo e($city['id']); ?>"
										    <?php if($city['id'] == $toilet[0]->city_id): ?>
										        selected="selected"
										    <?php endif; ?>
										    ><?php echo e($city['city']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
					</div>
				</div> 
					<div class="col-6 pr-0" >
						<div id="map" style="width:100%;height:400px;">
						</div>
						<input type="hidden" name="newLat" id="newLat" value="<?php echo e($toilet[0]->toilet_lat); ?>">
						<input type="hidden" name="newLng" id="newLng" value="<?php echo e($toilet[0]->toilet_lng); ?>">
						<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($key->mapkey); ?>&callback=myMap"></script>
					</div>
    			</div>
				<div class="modal-footer bg-light">
					<a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary" style="color: white!important;">Cancel</a>
					<button type="submit" id="btn-update" name="btn-update" class="btn btn-primary">Update Toilet</button>
				</div>
			</form>
	</section>
<script>
$(document).ready(function(){
	$("#country").on('change',function(){
		$.ajax({
			method:"GET",
			url:"<?php echo e(route('a.toilets.show',1)); ?>",
			data: {
               'country_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': '<?php echo e(method_field('GET')); ?>',
            },
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#state").html('<option>-No Governance found-</option>');
				else
					$("#state").html(data);
				$("#city").html('<option>-select-</option>');
			}
		});
	});

	$("#state").on('change',function(){
		$.ajax({
			method:"GET",
			url:"<?php echo e(route('a.toilets.show',1)); ?>",
			data: {
               'state_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': '<?php echo e(method_field('GET')); ?>',
            },
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#city").html('<option>-No city found-</option>');
				else
					$("#city").html(data);
			}
		});
	});
});
</script>
<?php $__env->stopSection(); ?>

<script>

    var marker;
    var infowindow;
    var myLatLng = {
     	lat: <?php echo e($toilet[0]->toilet_lat==null ? '51.508742' : $toilet[0]->toilet_lat); ?> , 
     	lng: <?php echo e($toilet[0]->toilet_lng==null ? '-0.120850' : $toilet[0]->toilet_lng); ?>

    };
    function myMap() {
        var mapProp= {
			center: myLatLng,
			zoom:15,
			gestureHandling: 'greedy'
		};
		var map = new google.maps.Map(document.getElementById("map"),mapProp);

		<?php echo e($toilet[0]->toilet_lat==null ? '' : 'placeMarker(map, myLatLng);'); ?>

        google.maps.event.addListener(map, 'click', function(event) {
            placeMarker(map, event.latLng);
        	document.getElementById("newLat").value = event.latLng.lat();
        	document.getElementById("newLng").value = event.latLng.lng();
        });
    }

    function placeMarker(map, location) {
        if (!marker || !marker.setPosition) {
            marker = new google.maps.Marker({
                position: location,
                map: map,
                animation: google.maps.Animation.DROP
            });
        } else {
        }
        marker.setPosition(location);
        if (infowindow && infowindow.close) {
            infowindow.close();
        }
        infowindow = new google.maps.InfoWindow({
            content: 'Set this location as a toilet spot '
        });
        infowindow.open(map,marker);
    }


</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/toilet/edit.blade.php ENDPATH**/ ?>