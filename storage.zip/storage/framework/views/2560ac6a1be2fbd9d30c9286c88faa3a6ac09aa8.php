<?php $__env->startSection('title','Ratings'); ?>


<?php $__env->startSection('rating'); ?>
    <section>
		<!-- Content Header (Page header) -->
    	<div class="content-header">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md text-center">
    					<h2>Your Toilet Ratings</h2>
    				</div><!-- /.col -->
    			 <!--Kishan changed  (Removed column for breadcrumb)-->

    			</div><!-- /.row -->
    			<HR width=50%>
    		</div><!-- /.container-fluid -->
    	</div>

    	<!-- /.content-header -->
		<div class="content-header mt-0 pt-0">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th>Toilet id</th>
					<th>Toilet name</th>
					<th>User id</th>
					<th width="22%">Rated</th>
					<th width="40%">Review</th>
					<th width="15%">Rated on</th>
				</tr>
				</thead>
				<tbody>
				<?php if( count($ratings) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No ratings yet</h2><hr></center></td></tr>
				<?php else: ?>
					<?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($rating->toilet_id); ?></td>
							<td title="<?php echo e($rating->toilet['address']); ?>">
								<?php echo e($rating->toilet['toilet_name']); ?>

							</td>
							<td title="<?php echo e($rating->user['name']); ?>">
								<?php echo e($rating->user['email']); ?>

							</td>
							<td title="<?php echo e($rating->rating); ?>">
								<?php for($i = 0; $i < 5; ++$i): ?>
								    <i class="font-20 fa fa-star<?php echo e($rating->rating<=$i?'-o':''); ?>" aria-hidden="true"></i>
								<?php endfor; ?>
							</td>
							<td><?php echo e($rating->desc); ?></td>
							<td><?php echo e($rating->created_at->format('d/m/Y').' at '.$rating->created_at->format('g:i A')); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/toiletowner/rating.blade.php ENDPATH**/ ?>