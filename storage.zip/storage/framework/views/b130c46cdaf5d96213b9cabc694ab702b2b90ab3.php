<?php $__env->startSection('title','Toilets'); ?>

<?php $__env->startSection('toiletowner.show'); ?>
<section>

	<div class="container pt-4">
		<div class="container col-md-auto">
			<div class="row">
				<div class="col-md-1 d-flex align-items-start flex-column">
						<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
				</div>
				<div class="col-md text-center">
					<h2>Profile of <b><?php echo e($name); ?></b></h2>
				</div>
				<div class="col-md-1"></div>
			</div>
			<hr width=50%>
			

			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col-auto">
							<h3 class="mb-0">Personal Details of <b><?php echo e($name); ?></b></h3>
						</div>
						<div class="col d-flex justify-content-end" title="Toiletowner id is a fixed attribute, thus can't be changed">
							<h4 class="mb-0">Toiletowner ID-<b><?php echo e($info[0]['id']); ?></b></h4>
						</div>
					</div>				</div>
				<div class="card-body">
					<h6 class="heading-small text-muted pl-3 mb-3">Profile Picture<span class="mx-3"></span> User information</h6>
					<div class="">
						<div class="row">
							<div class="px-4">
								<form method="POST" action="<?php echo e(route('personal.store')); ?>" enctype="multipart/form-data" id="imgform"> <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
									<div id="profileDiv" style="height: 100px;width: 100px;border: 1px dashed lightgrey;">

										<img src="<?php echo e(asset('profileimages/'.$info[0]['profile'])); ?>" alt="No image" class="profileimg" width="100" height="100">
										<div class="hoverabletext">
											<a href="#" class="imgtext fas fa-camera"></a>
										</div><br>
									</div>
									<div class="d-flex justify-content-center">
										<button class="text-primary btn btn-sm pointer" id="uploadImg">Upload</button>
									</div>
									<div id="uploadText" class="font-14 text-center"></div>
									<?php if ($errors->has('profile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('profile'); ?>
									<span class="text-danger font-14" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									<input type="file" name="profile" id="file" hidden>
								</form>
							</div>
							<div class="col-lg">
								<form action="<?php echo e(route('a.toiletowners.update',$info[0]['id'])); ?>" method="post"> <?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
									<div class="form-group">
										<label class="form-control-label" for="name">Name</label>
										<input type="text" id="ownername" name="ownername" class="form-control <?php if ($errors->has('ownername')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ownername'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Name" value="<?php echo e($info[0]['name']); ?>">
										<?php if ($errors->has('ownername')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ownername'); ?>
										    <span class="invalid-feedback" role="alert">
										        <strong><?php echo e($message); ?></strong>
										    </span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="col-lg">
									<div class="form-group">
										<label class="form-control-label" for="email">Email address</label>
										<input type="email" id="email" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" value="<?php echo e($info[0]['email']); ?>">
										<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
										    <span class="invalid-feedback" role="alert">
										        <strong><?php echo e($message); ?></strong>
										    </span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg mt-2 ml-3">
								<div class="form-group">
									<label class="form-control-label" for="password">New Password</label>
									<input type="password" id="password" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="New password" value="">
									<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
									    <span class="invalid-feedback" role="alert">
									        <strong><?php echo e($message); ?></strong>
									    </span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="col-lg mt-2 ml-3">
								<div class="form-group">
									<label class="form-control-label" for="password_confirmation">Password confirmation</label>
									<input type="text" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Re-type password" value="">
								</div>
							</div>
						</div>
						<hr class="my-2" />
						<!-- Address -->
						<h6 class="heading-small text-muted mb-4">Contact information</h6>
						<div class="pl-lg-4">
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label class="form-control-label" for="contactno">Contact no</label>
										<input type="text" id="contactno" name="contactno" class="form-control <?php if ($errors->has('contactno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contactno'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Contact" value="<?php echo e($info[0]['mobileno']); ?>">
										<?php if ($errors->has('contactno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contactno'); ?>
										    <span class="invalid-feedback" role="alert">
										        <strong><?php echo e($message); ?></strong>
										    </span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="col-md-8">
									<div class="form-group ml-5">
										<label class="form-control-label" for="autoalloc">Auto alloc toilets to users</label>
										<div class="custom-control custom-switch">
											<input type="checkbox" class="custom-control-input" name="autoalloc" id="autoalloc" value="<?php echo e($autoalloc[0]['auto_allocate']==0 ? '0' : '1'); ?>" <?php echo e($autoalloc[0]['auto_allocate']==1 ? 'checked' : ''); ?>>
											

											<label class="custom-control-label" style="font-size: 18px;" for="autoalloc">Auto allocate toilets</label>
										</div>
									</div>
								</div>
							</div>
							
							<button type="submit" id="submitbtn" name="submitbtn" class="btn btn-primary">Update</button>
						</div>
					</form>
				</div>
			</div>

		</div>
	</div>
<?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
</section>
<?php $__env->startSection('jquery'); ?>
<script>
	$(document).ready(function()
	{
		$('#autoalloc').change(function() {
        if($('#autoalloc').val()=='0')
        	$("#requestlink").hide();
        else
            $("#requestlink").show();
        $.ajax({
            url: '<?php echo e(route('a.toiletowners.store')); ?>',
            data: {
            		'id': <?php echo e($info[0]['id']); ?>,
                   'autoalloc': $('#autoalloc').val(),
                    '_token': $('input[name=_token]').val(),
                    '_method': $('input[name=_method]').val(),
                  },
            type: 'POST',
            dataType: 'json',
            success: function (response) {

                $('#autoalloc').attr('value', response.status);

            }
        });
    });
	});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/toiletowner/show.blade.php ENDPATH**/ ?>