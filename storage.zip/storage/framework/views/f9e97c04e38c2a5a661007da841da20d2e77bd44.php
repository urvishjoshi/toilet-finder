<?php $__env->startSection('title','Toiletuser'); ?>


<?php $__env->startSection('toiletuser.index'); ?>
<section>
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md text-center">    					
					<h2>Your Toilet Users</h2>
				</div><!-- /.col -->
				<!--Kishan changed  (Removed column for breadcrumb)-->

			</div><!-- /.row -->
			<HR width=50%>
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->
	<div class="content-header mt-0 pt-0">
		<div class="container-fluid">
			<div class="container justify-content-center" id="requestTable">
				<div class="card">
					<div class="card-header border-0 p-0">
						<div class="container justify-content-center p-0" id="requestTable">
							<table class="table align-items-center table-hover table-flush text-center mb-0">
								<thead>
									<tr class="thead-light">
										<th scope="col" center>Id</th>
										<th scope="col">Toilet name</th>
										<th scope="col">Address</th>
										<th scope="col">Usages</th>
										<th scope="col">View</th>
									</tr>
								</thead>
								<tbody>
									<?php if( count($usages) == 0 ): ?>
									<tr><td colspan="5"><center><h2>No usages yet</h2></center></td></tr>
									<?php else: ?>
									<?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($usage['id']); ?></td>
										<td><?php echo e($usage['toilet_name']); ?></td>
										<td title="<?php echo e($usage->getFullAddress()); ?>">
											<?php echo e($usage['address']); ?>

										</td>
										<td title="<?php echo e(count($usage->usages)); ?> peoples used this toilet">
											<?php echo e(count($usage->usages)); ?>

										</td>
										<td>
											<a href="<?php echo e(route('toiletusers.show',['id'=>$usage['id'],'toilet'=>$usage['toilet_name']])); ?>" class="btn btn-primary" name="view">View</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/toiletowner/toiletuser/index.blade.php ENDPATH**/ ?>