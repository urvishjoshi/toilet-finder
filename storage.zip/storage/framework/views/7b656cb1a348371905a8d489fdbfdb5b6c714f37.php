<?php $__env->startSection('title','Feedbacks'); ?>

<?php $__env->startSection('feedback'); ?>

<section>
    <!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
					<div class="col-md text-center">
    					<h2>Feedbacks</h2>
    				</div><!-- /.col -->
    			</div><!-- /.row -->
				<HR width=30%>

    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th scope="col">Id</th>
					<th scope="col">Feedbacker id</th>
					<th scope="col">Feedbacker</th>
					<th scope="col">Subject</th>
					<th scope="col">Description</th>
					<th scope="col">Received on</th>
				</tr>
				</thead>
				<tbody>
					<?php if( count($feedbacks) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No feedbacks</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th scope="row"><?php echo e($feedback->id); ?></th>
								<td><?php echo e($feedback->feedbacker_id); ?></td>
								<td><?php echo e($feedback->feedbacker_type=='1' ? 'Owner' : 'User'); ?></td>
								<td><?php echo e($feedback->subject); ?></td>
								<td><?php echo e($feedback->desc); ?></td>
								<td><?php echo e($feedback->created_at->format('d/m/Y').' at '.$feedback->created_at->format('g:i A')); ?></td>
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/feedback.blade.php ENDPATH**/ ?>