<?php $__env->startSection('title','Toiletuser'); ?>


<?php $__env->startSection('toiletuser'); ?>
    <section>
    	<!-- Content Header (Page header) -->
    	<div class="content-header">
    		<div class="container-fluid">
    			<div class="row">
				<div class="col-md text-center">    					
					<h2>Your Toilet Users</h2>
    			</div><!-- /.col -->
    			 <!--Kishan changed  (Removed column for breadcrumb)-->

    			</div><!-- /.row -->
    			<HR width=50%>
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th scope="col" center>Id</th>
					<th scope="col">Toilet name</th>
					<th scope="col">Address</th>
					<th scope="col">Usages</th>
					<th scope="col">View</th>
				</tr>
				</thead>
				<tbody>
				<?php if( count($usages) == 0 ): ?>
					<tr><td colspan="5"><center><h2>No usages yet</h2><hr></center></td></tr>
				<?php else: ?>
					<?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($usage['id']); ?></td>
							<td><?php echo e($usage['toilet_name']); ?></td>
							<td title="<?php echo e($usage->getFullAddress()); ?>">
								<?php echo e($usage['address']); ?>

							</td>
							<td><?php echo e(count($usage->usages)); ?></td>
							<td>
								<a href="<?php echo e(route('toiletusers.show',['id'=>$usage['id'],'name'=>$usage['toilet_name']])); ?>" class="btn btn-primary" name="view">View</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/toiletowner/toiletuser.blade.php ENDPATH**/ ?>