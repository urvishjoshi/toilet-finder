<?php $__env->startSection('title','Ratings'); ?>

<?php $__env->startSection('rating'); ?>

<section>
		<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md text-center">
    					<h2>Toilet Ratings</h2>
    				</div><!-- /.col -->

    			</div><!-- /.row -->
    			<HR width=50%>
				
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th>Id</th>
					<th>Toilet name</th>
					<th>Owner Id</th>
					<th>User Ids</th>
					<th>Ratings</th>
					<th>Votes</th>
					<th>View</th>
					
					
					
				</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $toilets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toilet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($toilet->id); ?></th>
						<td><?php echo e($toilet->toilet_name); ?></td>
						<td><?php echo e($toilet->owner_id); ?></td>
						<td>
							<?php echo e(count($toilet->ratings)); ?>

						</td>
						<td><?php echo e($toilet->getAverageRating()); ?></td>
						<td><?php echo e(count($toilet->ratings)); ?></td>
						<td>
							<a href="<?php echo e(route('a.ratings.show',$toilet->id)); ?>" class="btn btn-primary" name="view">View</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/rating.blade.php ENDPATH**/ ?>