<?php $__env->startSection('title','Toilets'); ?>

<?php $__env->startSection('toiletowner.show'); ?>
<section>

	<div class="container pt-4">
		<div class="container col-md-auto">
		<div class="row">
			<div class="col-md-1 d-flex align-items-start flex-column">
					<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
			</div>
			<div class="col-md text-center">
				<h2>Profile of <b><?php echo e($name); ?></b></h2>
			</div>
			<div class="col-md-1"></div>
		</div>
		<hr width=50%>
		

			<div class="container justify-content-center pt-3" id="requestTable">
				<table class="table table-hover">
				    <thead>
				    <tr class="thead-light">
				        <th scope="col" center>Id</th>
				        <th scope="col">Toilet name</th>
				        <th scope="col">Complex name</th>
				        <th scope="col">Address</th>
				        <th scope="col">Status</th>
				        <th scope="col">Created on</th>
				        <th scope="col">Price</th>
				    </tr>
				    </thead>
				    <tbody>
					<?php if( count($toilets) == 0 ): ?>
						<tr><td colspan="7"><center><h2>No Record found</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $toilets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toilet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th scope="row"><?php echo e($toilet->id); ?></th>
								<td><?php echo e($toilet->toilet_name); ?></td>
								<td><?php echo e($toilet->complex_name); ?></td>
								<td><?php echo e($toilet->address); ?></td>
								<td>
									<?php echo e($toilet->status=='1' ? 'Active' : 'Not active'); ?>

								</td>
								
								<td><?php echo e($toilet->created_at->format('d/m/Y').' at '.$toilet->created_at->format('g:i A')); ?></td>
								<td><b>$<?php echo e($toilet->price); ?></b></td>
								
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				    </tbody>
				</table>
			</div>

		</div>
	</div>

</section>

<script>
	$(document).ready(function()
	{
		function fetch_customer_data(query = '')
		{
			$.ajax({
				url:"return view('admin')",
				method:GET,
				data:{query,query},
				dataType:'Json'
				sucess:function(data)
				{
					$('tbody').html(data.table_data);
					$('#text_records').text(data.total_data)
				}
			})
		}
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/toiletowner/show.blade.php ENDPATH**/ ?>