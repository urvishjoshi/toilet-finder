<?php $__env->startSection('title','Ratings'); ?>

<?php $__env->startSection('rating.index'); ?>

<section>
		<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md text-center">
    					<h2>Toilet Ratings</h2>
    				</div><!-- /.col -->

    			</div><!-- /.row -->
    			<HR width=50%>
				
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th>Id</th>
					<th>Toilet name</th>
					<th>Owner Id</th>
					<th>Votes</th>
					<th>Avg Rating</th>
					<th>View</th>
				</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $toilets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toilet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($toilet->id); ?></th>
						<td><?php echo e($toilet->toilet_name); ?></td>
						<td title="<?php echo e($toilet->owner['email']); ?>">
							<?php echo e($toilet->owner_id); ?></td>
						<td>
							<?php echo e(count($toilet->ratings)); ?>

						</td>
						<td title="<?php echo e($toilet->getAverageRating()); ?>">
							<?php for($i = 0; $i < 5; ++$i): ?>
							    <i class="font-20 fa fa-star<?php echo e($toilet->getAverageRating()<=$i?'-o':''); ?>" aria-hidden="true"></i>
							<?php endfor; ?>
						</td>
						<td>
							<a href="<?php echo e(route('a.ratings.show',['id'=>$toilet->id,'name'=>$toilet->owner['name']])); ?>" class="btn btn-primary" name="view">View</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/rating/index.blade.php ENDPATH**/ ?>