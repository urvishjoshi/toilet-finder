<?php $__env->startSection('title','Toiletousers'); ?>

<?php $__env->startSection('toiletuser.show'); ?>

<section>
	<!-- Content Header (Page header) -->
	<div class="content pt-4">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-1 d-flex align-items-start flex-column" title="Active users">
					<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-3" style="font-size: 30px;text-decoration:none; "></a>
				</div>
				<div class="col-md text-center">
					<h2>Toilet Usages of <b><?php echo e($name); ?></b></h2>
				</div><!-- /.col -->
				<div class="col-md-1">

				</div>
			</div><!-- /.row -->
			<HR width=40%>
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="container justify-content-center" id="requestTable">
				<div class="card">
					<div class="card-header border-0 p-0">
						<div class="container justify-content-center p-0" id="requestTable">
							<table class="table align-items-center table-hover table-flush text-center mb-0">
								<thead>
									<tr class="thead-light">
										<th scope="col">Transact Id</th>
										<th scope="col">Owner Id</th>
										<th scope="col">User email</th>
										<th scope="col">Toilet used</th>
										<th scope="col">Used on</th>
									</tr>
								</thead>
								<tbody>
									<?php if( count($usages) == 0 ): ?>
									<tr><td colspan="6"><center><h2>No Usages</h2></center></td></tr>
									<?php else: ?>
									<?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<th><?php echo e($usage['transaction_id']); ?></th>
										<td><?php echo e($usage->owner['id']); ?></td>
										<td><?php echo e($usage->user['email']); ?></td>
										<td><?php echo e($usage->toilet['toilet_name']); ?></td>
										<td><?php echo e($usage['created_at']->format('d/m/Y').' at '.$usage['created_at']->format('g:i A')); ?></td>
								
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/toiletuser/show.blade.php ENDPATH**/ ?>