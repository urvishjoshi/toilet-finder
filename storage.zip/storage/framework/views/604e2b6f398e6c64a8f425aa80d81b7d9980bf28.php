<?php $__env->startSection('title','Toiletowners Status'); ?>

<?php $__env->startSection('request.show'); ?>
	<section>
		<div class="container pt-3 px-3">
			<div class="row">
				<div class="col-md-1 d-flex align-items-start flex-column">
					<a href="<?php echo e(route('a.requests.index')); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
				</div>
				<div class="col-md text-center">
					<h2 class="mb-0"> <?php echo e($status==1 ? 'Active owners' : 'Denied owners'); ?></h2>
				</div>
				<div class="col-md-1"></div>
			</div>

			<HR width=30% class="mt-1">
			<div class="container justify-content-center" id="requestTable">
				<table class="table table-hover">
				    <thead>
				    <tr class="thead-light">
				      <th scope="col" width="1%">Id</th>
				      <th scope="col">Name</th>
				      <th scope="col">Username</th>
				      <th scope="col">Registered on</th>
				      <th scope="col">Action</th>
				    </tr>
				    </thead>
				    <tbody>
				    <?php if( $owners->count() == 0 ): ?>
						<tr><td colspan="5"><center><h2>No owners</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th scope="row"><?php echo e($owner->id); ?></th>
								<td><?php echo e($owner->name); ?></td>
								<td><?php echo e($owner->email); ?></td>
								<td><?php echo e($owner->created_at->format('d/m/Y').' at '.$owner->created_at->format('g:i A')); ?></td>
								<td width="25%">
								<div class="row justify-content-center">

								<form action="<?php echo e(route('a.requests.update',$owner->id)); ?>" method="POST" class="form-inline">
								<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
								
									<a href="<?php echo e(route('a.toiletowners.show',['id'=>$owner->id,'name'=>$owner->name])); ?>" class="btn btn-primary" name="btn">View</a>&nbsp;&nbsp;
								<?php if( $status==-1 ): ?>
									<button class="btn btn-success" name="btn" type="submit" value="1">Approve</button>&nbsp;&nbsp;
								<?php else: ?>
									<button class="btn btn-warning" name="btn" type="submit" value="-1" onclick="return confirm('Denying a owner will remove all their toilets! Are you sure?');">Deny</button> &nbsp;&nbsp;
								<?php endif; ?>
								</form>

								<?php if( $status==-1 ): ?>
									<form action="<?php echo e(route('a.requests.update',$owner->id)); ?>" method="POST" class="form-inline">
									<?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
										<button class="btn btn-danger" name="btn" type="submit" value="-2">Delete</button>&nbsp;&nbsp;
									</form>
								<?php endif; ?>
								
								</div>
								</td>
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				    </tbody>
				</table>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/request/show.blade.php ENDPATH**/ ?>