<?php $__env->startSection('title','Login'); ?>


<?php $__env->startSection('content'); ?>
<div class="login-box mx-auto">
  <div class="login-logo">
    <a href="#"><b><?php echo e(isset($url) ? ucwords($url) : ""); ?> </b>Login</a><!--Kishan changed Link-->
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
     
      <p class="login-box-msg">Sign in to start your session</p> 

      <?php if(isset($url)): ?>
      <form method="POST" action='<?php echo e(url("$url/login")); ?>' aria-label="<?php echo e(__('Login')); ?>">
      <?php else: ?>
      <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
      <?php endif; ?>
          <?php echo csrf_field(); ?>
        <div class="form-group mb-3">
          <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" autocomplete="email" autofocus>

          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          
        </div>
        <div class="form-group mb-3">
          <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Password" autocomplete="current-password">

          <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          
        </div>
        <div class="row">
          
          <!-- /.col -->
          <div class="mx-auto col-3">
            <button type="submit" class="btn <?php if($url=='admin'): ?> btn-dark <?php else: ?> btn-primary <?php endif; ?> "> Login </button>

          </div>
          <!-- /.col -->
        </div>
      </form>

      
      <!-- /.social-auth-links -->
      <div class="col-10 ml-5"><!--Kishan changed (add column for adjust link) -->
        <p class="mb-1 ml-4">
            <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                    Forgot Your Password?
                </a>
            <?php endif; ?>
        </p>
        
        </div>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<?php if(Session::has('reg.msg')): ?>
    <div id="toast" class="mx-auto container row justify-content-center">
        <div class="alert bg-dark text-white" id="toast-body">
            <?php echo e(Session::get('reg.msg')); ?>

        </div>
    </div>
    <script>setTimeout(function() { $('#toast').fadeOut('slow'); }, 3500);</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/auth/login.blade.php ENDPATH**/ ?>