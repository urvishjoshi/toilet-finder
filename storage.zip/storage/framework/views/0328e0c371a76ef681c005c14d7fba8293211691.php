<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('toiletuser.profile'); ?>

	<section>
		<div class="content-header">
	<div class="container-fluid pt-2">
		<div class="col-xl-auto order-xl-1">
			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col-lg-auto">
							<h3 class="mb-0">Personal Details of <b><?php echo e($name); ?></b></h3>
						</div>
						<div class="col d-flex justify-content-end" title="User id is a fixed attribute, thus can't be changed">
							<h4 class="mb-0">User ID-<b><?php echo e($user->id); ?></b></h4>
						</div>
					</div>
				</div>
				<div class="card-body">
					<h6 class="heading-small text-muted mb-4">Login information</h6>
					<form action="<?php echo e(route('a.toiletusers.update',$user->id)); ?>" method="POST">
						<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
						<div class="pl-lg-4">
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<label class="form-control-label" for="name">Name</label>
										<input type="text" id="name" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Name" value="<?php echo e($user->name); ?>">
										<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<label class="form-control-label" for="email">Email address</label>
										<input type="email" id="email" name="email" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" value="<?php echo e($user->email); ?>">
										<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg mt-2">
									<div class="form-group">
										<label class="form-control-label" for="password">New Password</label>
										<input type="password" id="password" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="New password" value="">
										<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="col-lg mt-2">
									<div class="form-group">
										<label class="form-control-label" for="password_confirmation">Password confirmation</label>
										<input type="text" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Re-type password" value="">
									</div>
								</div>
							</div>
						</div>
						<hr class="my-2" />
						<!-- Address -->
						<h6 class="heading-small text-muted mb-4">Contact information</h6>
						<div class="pl-lg-4">
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label class="form-control-label" for="mobileno">Contact no</label>
										<input type="text" id="mobileno" name="mobileno" class="form-control <?php if ($errors->has('mobileno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobileno'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Contact" value="<?php echo e($user->mobileno); ?>">
										<?php if ($errors->has('mobileno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobileno'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label class="form-control-label" for="gender">Gender</label>
										<select class="custom-select" id="gender" name="gender">
											<option value="1" <?php echo e($user->gender=='1' ? 'selected':''); ?>>Male</option>
											<option value="0" <?php echo e($user->gender=='0' ? 'selected':''); ?>>Female</option>
										</select>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label class="form-control-label" for="age">Age</label>
										<input id="age" class="form-control <?php if ($errors->has('age')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('age'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="age"  placeholder="Age" value="<?php echo e($user->age); ?>" type="text">
										<?php if ($errors->has('age')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('age'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
							</div>
							<button type="submit" id="updatebtn" name="updatebtn" class="btn btn-primary">Update</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</div>

	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/toiletuser/edit.blade.php ENDPATH**/ ?>