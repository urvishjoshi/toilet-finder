<?php $__env->startSection('title','Feedbacks'); ?>

<?php $__env->startSection('feedback'); ?>

<section>
	<!-- Content Header (Page header) -->
	<div class="content pt-4">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md text-center">
					<h2>Feedbacks</h2>
				</div><!-- /.col -->
			</div><!-- /.row -->
			<HR width=30%>

		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="container justify-content-center" id="requestTable">
				<div class="card">
					<div class="card-header border-0 p-0">
						<div class="container justify-content-center p-0" id="requestTable">
							<table class="table align-items-center table-hover table-flush text-center mb-0">
								<thead>
									<tr class="thead-light">
										<th scope="col">Id</th>
										<th scope="col">Feedbacker id</th>
										<th scope="col">Feedbacker</th>
										<th scope="col">Subject</th>
										<th scope="col">Description</th>
										<th scope="col">Received on</th>
										<th scope="col">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php if( count($feedbacks) == 0 ): ?>
									<tr><td colspan="6"><center><h2>No feedbacks</h2><hr></center></td></tr>
									<?php else: ?>
									<?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<th scope="row"><?php echo e($feedback->id); ?></th>
										<td><?php echo e($feedback->feedbacker_id); ?></td>
										<td><?php echo e($feedback->feedbacker_type=='1' ? 'Owner' : 'User'); ?></td>
										<td><?php echo e($feedback->subject); ?></td>
										<td><?php echo e($feedback->desc); ?></td>
										<td><?php echo e($feedback->created_at->format('d/m/Y').' at '.$feedback->created_at->format('g:i A')); ?></td>
										<td>
											<form action="<?php echo e(route('a.feedbacks.destroy',$feedback->id)); ?>" method="POST">
												<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
												<button class="btn btn-sm btn-danger" name="btn" type="submit" value="delete">Delete</button>
											</form>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/feedback.blade.php ENDPATH**/ ?>