<?php $__env->startSection('title','Toiletousers'); ?>

<?php $__env->startSection('toiletuser'); ?>

<section>
    	<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md text-center">
    					<h2>Toilet Users</h2>
    				</div><!-- /.col -->
    			 <!--Kishan changed  (Removed column for breadcrumb)-->

    			</div><!-- /.row -->
    			<HR width=50%>
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th scope="col" center>Id</th>
					<th scope="col">User name</th>
					<th scope="col">User email</th>
					<th scope="col">Toilet used</th>
					<th scope="col">Approve this usage</th>
					
					<th scope="col">Manage</th>
					
				</tr>
				</thead>
				<tbody>
					<tr>
						<th scope="row">11</th>
						<td>ABC</td>
						<td>a@b.c</td>
						<td>XYZ toilet</td>
						<td>Yes | No</td>
						
						<td>
							<form action="" method="POST">
							<button class="btn btn-primary" name="approveBtn" type="submit" value="">View</button> &nbsp;&nbsp;
							<button class="btn btn-success" name="approveBtn" type="submit" value="">Manage</button> &nbsp;&nbsp;
							
							</form>
						</td>
						
					</tr>
					<tr>
						<th scope="row">11</th>
						<td>ABC</td>
						<td>a@b.c</td>
						<td>XYZ toilet</td>
						<td>Yes | No</td>
						
						<td>
							<form action="" method="POST">
							<button class="btn btn-primary" name="approveBtn" type="submit" value="">View</button> &nbsp;&nbsp;
							<button class="btn btn-success" name="approveBtn" type="submit" value="">Manage</button> &nbsp;&nbsp;
							
							</form>
						</td>
						
					</tr>
					<tr>
						<th scope="row">11</th>
						<td>ABC</td>
						<td>a@b.c</td>
						<td>XYZ toilet</td>
						<td>Yes | No</td>
						
						<td>
							<form action="" method="POST">
							<button class="btn btn-primary" name="approveBtn" type="submit" value="">View</button> &nbsp;&nbsp;
							<button class="btn btn-success" name="approveBtn" type="submit" value="">Manage</button> &nbsp;&nbsp;
							
							</form>
						</td>
						
					</tr>
					<tr>
						<th scope="row">11</th>
						<td>ABC</td>
						<td>a@b.c</td>
						<td>XYZ toilet</td>
						<td>Yes | No</td>
						
						<td>
							<form action="" method="POST">
							<button class="btn btn-primary" name="approveBtn" type="submit" value="">View</button> &nbsp;&nbsp;
							<button class="btn btn-success" name="approveBtn" type="submit" value="">Manage</button> &nbsp;&nbsp;
							
							</form>
						</td>
						
					</tr>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/toiletuser.blade.php ENDPATH**/ ?>