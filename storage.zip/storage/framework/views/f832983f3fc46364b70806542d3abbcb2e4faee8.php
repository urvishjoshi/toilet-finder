<?php $__env->startSection('title','Ratings'); ?>

<?php $__env->startSection('rating.show'); ?>

<section>
	<div class="container pt-4 px-3">
		<div class="row">
			<div class="col-md-1 d-flex align-items-start flex-column">
				<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
			</div>
			<div class="col-md text-center">
				<h2>Toilet Ratings of <b><?php echo e($name); ?></b></h2>
			</div><!-- /.col -->
			<div class="col-md-1"></div>
		</div>
		<HR width=60%>

	</div><!-- /.container-fluid -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="container justify-content-center" id="requestTable">
				<div class="card">
					<div class="card-header border-0 p-0">
						<div class="container justify-content-center p-0" id="requestTable">
							<table class="table align-items-center table-hover table-flush text-center mb-0">
								<thead>
									<tr class="thead-light">
										<th>Id</th>
										<th width="10%">Toilet name</th>
										<th width="8%">Owner Id</th>
										<th width="8%">User Id</th>
										<th width="20%">Rating</th>
										<th>Description</th>
										<th>Visible</th>
									</tr>
								</thead>
								<tbody>
									<?php if( count($ratings) == 0 ): ?>
									<tr><td colspan="6"><center><h2>No Ratings done yet</h2><hr></center></td></tr>
									<?php else: ?>
									<?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php for($i=0;$i<count($rating->ratings);$i++): ?>
									<tr>

										<th scope="row"><?php echo e($rating->ratings[$i]['id']); ?></th>
										<td><?php echo e($rating['toilet_name']); ?></td>
										<td>
											<?php echo e($rating['owner_id']); ?>

										</td>
										<td><?php echo e($rating->ratings[$i]['user_id']); ?></td>
										<td title="<?php echo e($rating->ratings[$i]['rating']); ?>">
											<?php for($j = 0; $j < 5; ++$j): ?>
											<i class="font-20 fa fa-star<?php echo e(($rating->ratings[$i]['rating'])<=$j?'-o':''); ?>" aria-hidden="true"></i>
											<?php endfor; ?>
										</td>
										<td><?php echo e($rating->ratings[$i]['desc']); ?></td>
										<td class="" for="<?php echo e($rating->ratings[$i]['id']); ?>">
											<div class="custom-control custom-switch" for="<?php echo e($rating->ratings[$i]['id']); ?>">
												<input type="checkbox" class="custom-control-input" name="<?php echo e($rating->ratings[$i]['id']); ?>" id="<?php echo e($rating->ratings[$i]['id']); ?>" value="<?php echo e($rating->ratings[$i]['visible']=='0' ? '0' : '1'); ?>" <?php echo e($rating->ratings[$i]['visible']=='1' ? 'checked' : ''); ?>>
												<?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
											      
												<label class="custom-control-label" for="<?php echo e($rating->ratings[$i]['id']); ?>" style="font-size: 18px;"></label>
											</div>
										</td>
									</tr>
									<?php endfor; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /.content-header -->
</section>
<script>

$(document).ready(function() {
    $('.custom-control-input').change(function() {
        console.log($(this).val())
        $.ajax({
            url: '<?php echo e(route('a.ratings.store')); ?>',
            data: {
                   'visible': $(this).val(),
                   'id': $(this).attr('id'),
                    '_token': $('input[name=_token]').val(),
                    '_method': $('input[name=_method]').val(),
                  },
            type: 'POST',
            dataType: 'json',
            success: function (response) {

                $(this).val(response.visible);

            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/rating/show.blade.php ENDPATH**/ ?>