<?php $__env->startSection('title','Toiletousers'); ?>

<?php $__env->startSection('toiletuser.show'); ?>

<section>
    	<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md-1 d-flex align-items-start flex-column" title="Active users">
						<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-3" style="font-size: 30px;text-decoration:none; "></a>
					</div>
    				<div class="col-md text-center">
    					<h2><b><?php echo e($name); ?></b></h2>
    				</div><!-- /.col -->
    				<div class="col-md-1">
    					
    				</div>
    			</div><!-- /.row -->
    			<HR width=40%>
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th scope="col">Transact Id</th>
					<th scope="col">Owner Id</th>
					<th scope="col">User email</th>
					<th scope="col">Toilet used</th>
					
					
					
				</tr>
				</thead>
				<tbody>
					<?php if( count($usages) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No Requests</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th><?php echo e($usage['transaction_id']); ?></th>
								<td><?php echo e($usage->owner['id']); ?></td>
								<td><?php echo e($usage->user['email']); ?></td>
								<td><?php echo e($usage->toilet['toilet_name']); ?></td>
								
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/toiletuser/show.blade.php ENDPATH**/ ?>