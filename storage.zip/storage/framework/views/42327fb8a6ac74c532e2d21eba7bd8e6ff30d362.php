<!DOCTYPE html>
<html lang="en">
<head>
	<?php $__env->startSection('session','Admin'); ?>
	<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php $allRequests=\App\Model\ToiletOwner::where('status','=','0')->get(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini layout-fixed">
	<div class="wrapper">
		<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="content-wrapper">
			<?php echo $__env->yieldContent('home'); ?>
			<?php echo $__env->yieldContent('request.index'); ?>
				<?php echo $__env->yieldContent('request.show'); ?>

				<?php echo $__env->yieldContent('toiletowner.index'); ?>
				<?php echo $__env->yieldContent('toiletowner.show'); ?>

				<?php echo $__env->yieldContent('toiletuser.index'); ?>
				<?php echo $__env->yieldContent('toiletuser.show'); ?>

				<?php echo $__env->yieldContent('toilet.index'); ?>
				<?php echo $__env->yieldContent('toilet.show'); ?>

				<?php echo $__env->yieldContent('rating.index'); ?>
				<?php echo $__env->yieldContent('rating.show'); ?>
			<?php echo $__env->yieldContent('sale'); ?>
			<?php echo $__env->yieldContent('permission'); ?>
			<?php echo $__env->yieldContent('report'); ?>
			<?php echo $__env->yieldContent('feedback'); ?>
			<?php echo $__env->yieldContent('location'); ?>

			<?php if(Session::has('a.toast')): ?>
				<div id="toast" class="mx-auto container row justify-content-center">
					<div class="alert bg-dark text-white" id="toast-body">
						<?php echo e(Session::get('a.toast')); ?>

					</div>
				</div>
				<script>setTimeout(function() { $('#toast').fadeOut('slow'); }, 3500);</script>
			<?php endif; ?>
			
		</div>
		<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>