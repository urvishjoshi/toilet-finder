<?php $__env->startSection('title','Toilet Locations'); ?>

<?php $__env->startSection('location'); ?>

<section>
	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md-1 d-flex align-items-start flex-column">
						<a href="<?php echo e(url('admin/locations')); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
					</div>
					<div class="col-md text-center">
    					<h2>Edit locations</h2>
    				</div><!-- /.col -->
    				<div class="col-md-1"></div>
    			</div><!-- /.row -->
				<HR width=30%>

    		</div><!-- /.container-fluid -->
    	</div>

	<div class="content-header">
		<div class="container">
 			<?php echo method_field('GET'); ?> <?php echo csrf_field(); ?>
 			<h6 class="heading-small text-muted mb-2">Edit Country</h6>
 			<form action="<?php echo e(route('a.locations.update',1)); ?>" method="POST">
 				<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
 				<div class="row">
					<div class="col-lg-4">
							<div class="form-group">
								<label for="countryId">Select Country</label>
								<select name="countryId" class="form-control" id="countryId" required>
									<option value="">select</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 						</select>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="form-group">
								<label for="editCountry">New Country name</label>
								<input type="text" name="editCountry" id="editCountry" class="form-control" placeholder="Edit Country" value="" required>
							</div>
						</div>
					<div class="col-lg-2">
						<div class="form-group">
							<label for="addCountry"></label>
							<button type="submit" class="btn btn-success d-flex align-items-end mt-2" name="countryEditBtn" value="1">Edit Country</button>
						</div>
					</div>
				</div>
 			</form>
			<hr>
			<form action="<?php echo e(route('a.locations.update',1)); ?>" method="POST">
 				<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
				<h6 class="heading-small text-muted mb-2">Edit Governance</h6>
 				<div class="row">
					<div class="col-lg-3">
							<div class="form-group">
								<label for="country">Country</label>
								<select name="country" class="form-control" id="countrydelstate" required>
									<option value="">select</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="form-group">
								<label for="state">Governance</label>
								<select name="stateId" class="form-control" id="statedelstate" required>
									<option value="">-select-</option>
								</select>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="form-group">
								<label for="editState">New Governance name</label>
								<input type="text" name="editState" id="editState" class="form-control" placeholder="Edit Governance" value="" required>
							</div>
						</div>
					<div class="col-lg-2">
						<div class="form-group">
							<label for="city"></label>
							<button type="submit" class="btn btn-success d-flex align-items-end mt-2" name="stateEditBtn" value="1">Edit Governance</button>
						</div>
					</div>
				</div>
			</form>

				<hr>

			<form action="<?php echo e(route('a.locations.update',1)); ?>" method="POST">
 				<?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
				<h6 class="heading-small text-muted mb-2">Edit city</h6>
 				<div class="row">
					<div class="col-lg">
							<div class="form-group">
								<label for="country">Country</label>
								<select name="country" class="form-control" id="countrydelcity" required>
									<option value="">select</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-lg">
							<div class="form-group">
								<label for="state">Governance</label>
								<select name="state" class="form-control" id="statedelcity" required>
									<option value="">-select-</option>
								</select>
							</div>
						</div>
						<div class="col-lg">
							<div class="form-group">
								<label for="city">City</label>
								<select name="cityId" class="form-control" id="citydelcity" required>
									<option value="">-select-</option>
								</select>
							</div>
						</div>
						<div class="col-lg">
							<div class="form-group">
								<label for="editCity">New City name</label>
								<input type="text" name="editCity" id="editCity" class="form-control" placeholder="Edit City" value="" required>
							</div>
						</div>
					<div class="">
						<div class="form-group">
							<label for="city"></label>
							<button type="submit" class="btn btn-success d-flex align-items-end mx-2 mt-2" name="cityEditBtn" value="1">Edit City</button>
						</div>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</section>


<script>
$(document).ready(function(){

	$(document).on('change','#countryId',function(e){
		$("#editCountry").attr('value', $(this).find('option:selected').text());
	});
	$(document).on('change','#statedelstate',function(e){
		$("#editState").attr('value', $(this).find('option:selected').text());
	});
	$(document).on('change','#citydelcity',function(e){
		$("#editCity").attr('value', $(this).find('option:selected').text());
	});
	$("#country").on('change',function(){
		$.ajax({
			method:"POST",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
               'country_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': $('input[name=_method]').val(),
            },
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#state").html('<option>-No Governance found-</option>');
				else
					$("#state").html(data);
			}
		});
	});

	$("#state").on('change',function(){
		$.ajax({
			method:"POST",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
               'state_id': $(this).val(),
                '_token': $('input[name=_token]').val(),
                '_method': $('input[name=_method]').val(),
            },
			dataType:'html',
			success:function(data){
				// $("#city").html(data);
			}
		});
	});
	//////////////////////////////////////////
	$("#countrydelstate").on('change',function(){
		$.ajax({
			method:"GET",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
			   'country_id': $(this).val(),
				'_token': $('input[name=_token]').val(),
				'_method': '<?php echo e(method_field('GET')); ?>',
			},
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#statedelstate").html('<option value="">-No Governance found-</option>');
				else
					$("#statedelstate").html(data);
				$("#citydelstate").html('<option value="">-select-</option>');
			}
		});
	});

	$("#countrydelcity").on('change',function(){
		$.ajax({
			method:"GET",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
			   'country_id': $(this).val(),
				'_token': $('input[name=_token]').val(),
				'_method': '<?php echo e(method_field('GET')); ?>',
			},
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#statedelcity").html('<option value="">-No Governance found-</option>');
				else
					$("#statedelcity").html(data);
				$("#citydelcity").html('<option value="">-select-</option>');
			}
		});
	});
	$("#statedelcity").on('change',function(){
		$.ajax({
			method:"GET",
			url:"<?php echo e(route('a.locations.show',1)); ?>",
			data: {
			   'state_id': $(this).val(),
				'_token': $('input[name=_token]').val(),
				'_method': '<?php echo e(method_field('GET')); ?>',
			},
			dataType:'html',
			success:function(data){
				if(data<1)
					$("#citydelcity").html('<option value="">-No city found-</option>');
				else
					$("#citydelcity").html(data);
			}
		});
	});
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\toiletfinder\resources\views/admin/location/edit.blade.php ENDPATH**/ ?>