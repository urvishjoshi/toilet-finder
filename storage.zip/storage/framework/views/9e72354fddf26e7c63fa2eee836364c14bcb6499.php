<?php $__env->startSection('title','Toiletuser'); ?>


<?php $__env->startSection('toiletuser.show'); ?>
    <section>
    	<!-- Content Header (Page header) -->
    	<div class="content-header">
    		<div class="container-fluid">
    			<div class="row">
    			<div class="col-md-1 d-flex align-items-start flex-column">
					<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
				</div>
				<div class="col-md text-center">    					
					<h2>Users of <b><?php echo e($toilet); ?></b> Toilet</h2>
    			</div><!-- /.col -->
				<div class="col-md-1"></div>
    			</div><!-- /.row -->
    			<HR width=40%>
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header pt-0">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th>Transaction Id</th>
					<th>User email</th>
					<th>User name</th>
					<th>Gender</th>
					<th>Used on</th>
				</tr>
				</thead>
				<tbody>
				<?php if( count($usages) == 0 ): ?>
					<tr><td colspan="6"><center><h2>No usages yet</h2><hr></center></td></tr>
				<?php else: ?>
					<?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($usage->transaction_id); ?></td>
							<td><?php echo e($usage->user['email']); ?></td>
							<td><?php echo e($usage->user['name']); ?></td>
							<td>
								<?php echo e($usage->user['gender']==1 ? 'Male' : 'Female'); ?>

							</td>
							<td>
								<?php echo e($usage->created_at->format('d/m/Y').' at '.$usage->created_at->format('g:i A')); ?>

							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toiletowner.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/toiletowner/toiletuser/show.blade.php ENDPATH**/ ?>