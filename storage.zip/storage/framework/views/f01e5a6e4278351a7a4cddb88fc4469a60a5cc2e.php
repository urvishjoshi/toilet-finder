<?php $__env->startSection('title','Ratings'); ?>

<?php $__env->startSection('rating.show'); ?>

<section>
		<div class="container pt-4 px-3">
			<div class="row">
				<div class="col-md-1 d-flex align-items-start flex-column">
					<a href="<?php echo e(url()->previous()); ?>" class="fas fa-arrow-left pt-3 pl-2" style="font-size: 30px;text-decoration:none; "></a>
				</div>
				<div class="col-md text-center">
					<h2>Toilet Ratings of <b><?php echo e($name); ?></b></h2>
				</div><!-- /.col -->
				<div class="col-md-1"></div>
			</div>
    			<HR width=60%>
				
    		</div><!-- /.container-fluid -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th>Id</th>
					<th width="10%">Toilet name</th>
					<th width="8%">Owner Id</th>
					<th width="8%">User Id</th>
					<th width="20%">Rating</th>
					<th>Description</th>
				</tr>
				</thead>
				<tbody>
				<?php if( count($ratings) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No Ratings done yet</h2><hr></center></td></tr>
				<?php else: ?>
				<?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php for($i=0;$i<count($rating->ratings);$i++): ?>
					<tr>
						
						<th scope="row"><?php echo e($rating->ratings[$i]['id']); ?></th>
						<td><?php echo e($rating['toilet_name']); ?></td>
						<td>
							<?php echo e($rating['owner_id']); ?>

						</td>
						<td><?php echo e($rating->ratings[$i]['user_id']); ?></td>
						<td title="<?php echo e($rating->ratings[$i]['rating']); ?>">
							<?php for($j = 0; $j < 5; ++$j): ?>
							    <i class="font-20 fa fa-star<?php echo e(($rating->ratings[$i]['rating'])<=$j?'-o':''); ?>" aria-hidden="true"></i>
							<?php endfor; ?>
						</td>
						<td><?php echo e($rating->ratings[$i]['desc']); ?></td>
					</tr>
					<?php endfor; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    	</div>
    	<!-- /.content-header -->
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/rating/show.blade.php ENDPATH**/ ?>