<?php $__env->startSection('title','Toilets'); ?>

<?php $__env->startSection('toilet'); ?>

<section>
    	<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
					<div class="col-md text-center">
    					<h2>All Toilets</h2>
    				</div><!-- /.col -->

    			</div><!-- /.row -->
				<HR width=50%>

    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th scope="col">Id</th>
					<th scope="col">Owner id</th>
					<th scope="col">Toilet name</th>
					<th scope="col">Price</th>
					<th scope="col">Created on</th>
				</tr>
				</thead>
				<tbody>
					<?php if( count($toilets) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No Toilets registered</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $toilets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toilet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th scope="row"><?php echo e($toilet->id); ?></th>
								<td title="<?php echo e($toilet->owner['email']); ?>">
									<?php echo e($toilet->owner['id']); ?>

								</td>
								<td><?php echo e($toilet->toilet_name); ?></td>
								<td><b>$<?php echo e($toilet->price); ?></b></td>
								<td><?php echo e($toilet->created_at); ?></td>
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/toilet.blade.php ENDPATH**/ ?>