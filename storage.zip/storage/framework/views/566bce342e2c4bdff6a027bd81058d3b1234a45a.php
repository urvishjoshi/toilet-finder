<?php $__env->startSection('title','Toiletousers'); ?>

<?php $__env->startSection('toiletuser.index'); ?>

<section>
    	<!-- Content Header (Page header) -->
    	<div class="content pt-4">
    		<div class="container-fluid">
    			<div class="row">
    				<div class="col-md text-center">
    					<h2>Toilet Users</h2>
    				</div><!-- /.col -->
    			 <!--Kishan changed  (Removed column for breadcrumb)-->

    			</div><!-- /.row -->
    			<HR width=50%>
    		</div><!-- /.container-fluid -->
    	</div>
    	<!-- /.content-header -->
		<div class="content-header">
		<div class="container-fluid">
		<div class="container justify-content-center" id="requestTable">
			<table class="table table-hover">
				<thead>
				<tr class="thead-light">
					<th center>Id</th>
					<th>User name</th>
					<th>User email</th>
					<th>Mobile no</th>
					<th>Gender</th>
					<th>Age</th>
					<th>Registered on</th>
					<th>Usages</th>
					<th width="17%">View</th>
				</tr>
				</thead>
				<tbody>
					<?php if( count($users) == 0 ): ?>
						<tr><td colspan="6"><center><h2>No Requests</h2><hr></center></td></tr>
					<?php else: ?>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
								<th scope="row"><?php echo e($user->id); ?></th>
								<td><?php echo e($user->name); ?></td>
								<td><?php echo e($user->email); ?></td>
								<td><?php echo e($user->mobileno); ?></td>
								<td><?php echo e($user->gender==1 ? 'Male' : 'Female'); ?></td>
								<td><?php echo e($user->age); ?></td>
								<td><?php echo e($user->created_at->format('d/m/Y').' at '.$user->created_at->format('g:i A')); ?></td>
								<td><?php echo e(count($user->toiletusages)); ?></td>
								<td>
								<form action="<?php echo e(route('a.toiletusers.destroy',$user->id)); ?>" method="POST">
								<?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
									<a href="<?php echo e(route('a.toiletusers.show',[$user->id,'name'=>$user->name])); ?>" class="btn btn-primary" name="btn" type="submit" value="view">View</a>&nbsp;
									
									<button class="btn btn-danger" name="btn" type="submit" value="delete">Delete</button>

								</form>
								</td>
						    </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
			</table>
			</div>
			</div>	
	</div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/toiletuser/index.blade.php ENDPATH**/ ?>