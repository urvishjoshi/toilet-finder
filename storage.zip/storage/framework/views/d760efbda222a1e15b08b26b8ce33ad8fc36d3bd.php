<?php $__env->startSection('title','Reports'); ?>

<?php $__env->startSection('report'); ?>
<section>
	<div class="container pt-3">
		<div class="container col-auto pb-0">
			<div class="row pb-0">
				<div class="col-md pb-0 text-center">
					<h2 class=" mb-0">Toilet Reports</h2>
				</div>
			</div>
			<HR width=50%>
		</div>
	</div>
	<div class="content-header mt-0 pt-1">
		<div class="container-fluid">
			<div>
				<form action="<?php echo e(route('a.reports.show',1)); ?>" method="post" id="form" class="row justify-content-center">
				<?php echo method_field('GET'); ?> <?php echo csrf_field(); ?>
				<div class="col-md-auto" id="monthDiv">
					<select class="custom-select" id="selectRange" name="selectRange">
						<option disabled>Select range</option>
						<option value="7">7 days</option>
						<option value="31">30 days</option>
						<option value="6">6 months</option>
						<option value="12">1 year</option>
						<option value="1">All</option>
					</select>
				</div>
				<div class="col-md-auto">
					<button class="btn btn-primary" value="getRecord" name="getRecord" type="submit">Get Record</button>
				</div>
				</form>
			</div>
		</div>
		<div class="container-fluid justify-content-center mt-3">
			<table class="table table-hover">
				<thead><?php $total=0 ?>
				<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $total+=$sale->toilet['price']; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				<tr class="thead-light">
					<th>Id</th>
					<th>Transact Id</th>
					<th>Owner id</th>
					<th>User id</th>
					<th>Toilet id</th>
					<th title="Total revenue is <b>$<?php echo e($total); ?></b>">Paid | <b class="text-success">$<?php echo e($total); ?></b></th>
					<th>Used on</th>
				</tr>
				</thead>
				<tbody>
				<?php if( count($sales) == 0 ): ?>
					<tr><td colspan="7"><center><h2>No Reports found</h2><hr></center></td></tr>
				<?php else: ?>
					
					<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
							<th scope="row"><?php echo e($sale->id); ?></th>
							<td><?php echo e($sale->transaction_id); ?></td>
							<td title="<?php echo e($sale->owner['email']); ?>">
								<?php echo e($sale->owner['id']); ?>

							</td>
							<td title="<?php echo e($sale->user['email']); ?>">
								<?php echo e($sale->user['id']); ?>

							</td>
							<td title="<?php echo e($sale->toilet['toilet_name']); ?>">
								<?php echo e($sale->toilet_id); ?>

							</td>
							<td><b>$<?php echo e($sale->toilet['price']); ?></b></td>
							<td><?php echo e($sale->created_at->format('d/m/Y').' at '.$sale->created_at->format('g:i A')); ?></td>
					    </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/report/show.blade.php ENDPATH**/ ?>