<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('home'); ?>
<?php $owners=\App\Model\ToiletOwner::all()->count(); ?>
<?php $users=\App\User::all()->count(); ?>
<?php $toilets=\App\Model\ToiletInfo::where('status','=','1')->count(); ?>
<?php $sales=\App\Model\ToiletUsageInfo::all()->count(); ?>
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-9">
          <h1 class="m-0 text-dark">Dashboard</h1>
        </div><!-- /.col -->
          <div class="custom-control custom-switch ml-4">
          <input type="checkbox" class="custom-control-input" name="autoalloc" id="autoalloc" value=>
          <?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
          
          <label class="custom-control-label" style="font-size: 18px;" for="autoalloc">Auto approve requests</label>
        </div>
         <!--Kishan changed  (Removed column for breadcrumb)-->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="h-100 small-box bg-warning border border-light">
              <div class="inner">
                <h3 ><?php echo e($owners); ?></h3>

                <h4>Toilet Owners</h4><!--Kishan changed  New Orders -->
              </div>
              <div class="icon">
                <i class="fas fa-user-tie"></i>
              </div>
              
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="h-100 small-box bg-lightblue border border-light">
              <div class="inner">
                <h3><?php echo e($users); ?></h3>

                <h4>Toilet Users</h4><!--Kishan changed Bounce Rate-->
              </div>
              <div class="icon">
                <i class="fas fa-users"></i>
              </div>
              <!--<a href="#" class="h-100 small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>-->
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="h-100 small-box bg-teal border border-light">
              <div class="inner">
                <h3><?php echo e($toilets); ?></h3>

                <h4>Active Toilets</h4><!--Kishan changed User Registrations-->
              </div>
              <div class="icon">
                <i class="material-icons" style="color:##006652;">flash_on</i>
              </div>
              
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="h-100 small-box bg-maroon border border-light">
              <div class=" inner">
                <h3><?php echo e($sales); ?></h3>

                <h4>Sales</h4>
              </div>
              <div class="icon">
                <i class="fa fa-line-chart" aria-hidden="true"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
    
        </div>
        <!-- /.row -->
       
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->

<!-- kishan removed  3 unnecessary div  -->

  </section>
  <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toiletfinder\resources\views/admin/home.blade.php ENDPATH**/ ?>